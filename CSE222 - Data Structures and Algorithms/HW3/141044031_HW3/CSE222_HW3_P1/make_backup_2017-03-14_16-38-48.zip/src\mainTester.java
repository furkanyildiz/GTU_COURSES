import java.io.*;
import java.util.LinkedList;

public class mainTester {
    public static void main(String[] args) throws FileNotFoundException {

        LinkedList a = new LinkedList<String>();
        char arr[] = "furkanyıl".toCharArray();
        StringBuilder s = new StringBuilder();
        myStringBuilder l = new myStringBuilder();
        System.out.println(l.append('f'));
        System.out.println(s.append('f'));

        l.append(23);
        s.append(23);
        System.out.println(l.append('r'));
        System.out.println(s.append('r'));

        l.append(true);
        s.append(true);
        l.append(false);
        s.append(false);

        //System.out.println(s.append(true).getClass());
        s.append(s,2,4);
        System.out.println(s);
        l.append(s,2,4);
        System.out.println(l);

        l.append('f');
        l.append(23);
        l.append(true);
        l.append(53);
        l.append(false);
        l.delete(53);
        l.delete('f');
        System.out.println(l);
        System.out.println(l.toString2());
        System.out.println(l.toString3());
/*
        myStringBuilder msb = new myStringBuilder();

        msb = readToFile("numbers.txt");

        String result1 = msb.toString();
        String result2 = msb.toString2();
        String result3 = msb.toString3();
        writeToFile("a.txt",result1);
*/
    }

    /**
     * To write a file given strings
     * @param filename filename
     * @param str string which will be writing to file.
     * @throws IOException if file is not found.
     */
    public static void writeToFile(String filename,String str) throws IOException {

        try {
            FileWriter writer = new FileWriter(filename, true);
            writer.write(str);
            writer.close();

        } catch (IOException e) {
            throw e;
        }

    }

    /**
     * To read a file
     * @param filename file name
     * @return myStringBuilder object with appended values from file.
     * @throws IOException if file is not found.
     */
    public static myStringBuilder readToFile(String filename) throws IOException {
        InputStream in = new FileInputStream(new File(filename));
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        myStringBuilder out = new myStringBuilder();
        String line;
        int i =0;
        try {
            while ((line = reader.readLine()) != null) {
                out.append(line);
                System.out.println(i++);
            }
            reader.close();

        }
        catch (IOException e){
            throw  e;
        }
        return out;
    }

}
